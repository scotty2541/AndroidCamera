package com.example.barcodedecode;

import android.content.Context;
import android.graphics.Rect;
import android.hardware.Camera;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;

import com.google.android.gms.vision.barcode.BarcodeDetector;

import java.util.ArrayList;

/**
 * Created by scott on 4/5/2019.
 */


public class CameraPreview extends SurfaceView implements Callback {
    private SurfaceHolder m_holder;
    private Camera m_camera;
    private BarcodeDetector m_detector;
    private Context m_context;

    public CameraPreview(Context context, Camera camera) {
        super(context);
        m_context = context;
        m_camera = camera;
        m_holder = getHolder();
        m_holder.addCallback(this);
        m_holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);


    }
    public void surfaceCreated(SurfaceHolder holder) {
        try {

            Camera.Parameters params;
            params = m_camera.getParameters();
            params.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
            params.setFocusMode(Camera.Parameters.FOCUS_MODE_MACRO);
           // params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            if (params.getMaxNumFocusAreas() > 0) {
                ArrayList<Camera.Area> focusAreas = new ArrayList<Camera.Area>(1);
                focusAreas.add(new Camera.Area(new Rect(0, 0, 100, 100), 750));
                params.setFocusAreas(focusAreas);
            }
            m_camera.setParameters(params);
            m_camera.setPreviewDisplay(holder);
            m_camera.startPreview();

        } catch (Exception e) {

        }
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
    }
    public void surfaceChanged(SurfaceHolder holder,  int format, int w, int h) {
        if (m_holder.getSurface() == null) {
            return;
        }
        try {
            m_camera.stopPreview();
        } catch (Exception e) {

        }
        try {
            m_camera.setPreviewDisplay(m_holder);
            m_camera.startPreview();
        } catch (Exception e) {
        }
    }

}
