package com.example.barcodedecode;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.util.SparseArray;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;

/**
 * Created by scott on 4/8/2019.
 */

public class Decode implements Camera.AutoFocusCallback {
    private Camera.PictureCallback m_picture;
    private Bitmap bitmap;
    private MainActivity m_context;
    private String m_data;

    public Decode(Context context) {
        m_context = (MainActivity) context;
        m_picture = new Camera.PictureCallback() {
            @Override
            public void onPictureTaken(byte[] bytes, Camera camera) {
                Barcode barcode = null;
                bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);

                BarcodeDetector detector = new BarcodeDetector.Builder(
                        m_context)
                        .setBarcodeFormats(Barcode.DATA_MATRIX | Barcode.QR_CODE | Barcode.PDF417).
                                build();
                if (!detector.isOperational()) {
                    return;
                }
                Frame frame = new Frame.Builder().setBitmap(bitmap).build();
               /*  ADD TESTS AND TRAPS  */
                try {
                    SparseArray<Barcode> barcodes = detector.detect(frame);
                    barcode = barcodes.valueAt(0);
                } catch (Exception e) {

                }
                if (barcode != null) {
                    m_data = barcode.rawValue;
                    m_context.BarcodeData(m_data);
                } else {
                    m_context.TryAgain();
                }
            }
        };
    }
@Override
    public void onAutoFocus(boolean success, Camera camera) {
        if (success) {
            camera.takePicture(null, null, m_picture);
        } else {
            m_context.TryAgain();
        }
    }
}
