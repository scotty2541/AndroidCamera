package com.example.barcodedecode;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class Main2Activity extends AppCompatActivity {
    private final int CAMERA_REQUEST = 1;
    private String m_data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }
    public void OpenCamera(View view) {

        Intent intent = new Intent(this,MainActivity.class);
        startActivityForResult(intent,CAMERA_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == CAMERA_REQUEST) {
            if (resultCode == RESULT_OK) {
                m_data = data.getStringExtra(MainActivity.EXTRA_REPLY);
                if (m_data.length() > 0) {

                }
            }
        }
    }


}
