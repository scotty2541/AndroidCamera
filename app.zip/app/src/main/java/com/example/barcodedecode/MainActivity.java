package com.example.barcodedecode;

import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.widget.FrameLayout;
import android.widget.TextView;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_REPLY = "extra.REPLY";

    private final Handler m_handler = new Handler();
    private TextView m_status;
    private boolean m_cameraPresent;
    private CameraPreview m_preview;
    private FrameLayout m_cameraFrame;
    private Decode m_decode;
    private String m_data;

    private Camera m_camera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        m_status = (TextView) findViewById(R.id.textView);
        m_cameraFrame = (FrameLayout) findViewById(R.id.camerapreview) ;
        m_camera = null;
        m_preview = null;
        m_decode = null;

        m_cameraPresent = getApplicationContext().getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA);
        if (m_cameraPresent == false) {
            m_status.setText("No Camera was found on this device");

        }
        ActivateCamera();
    }

    final Runnable UpdateScreen = new Runnable() {
        public void run() {
            int x;
            String user;
            String key, value;
            JSONObject jitem;
            m_cameraFrame.removeAllViews();
			m_status.setText(m_data);
        }
    };

    public void BarcodeData(String data) {
        m_data = data;
        m_handler.post(UpdateScreen);
    }

    final Runnable Refocus = new Runnable() {
        public void run() {
            m_camera.autoFocus(m_decode);
        }
    };
    public void TryAgain() {
        m_handler.post(Refocus);

    }
    @Override
    public void onPostResume() {
        super.onPostResume();
        if (m_camera == null) {
            ActivateCamera();
        }
        if (m_camera != null) {


        }
    }
    @Override
    public void onPause() {
        super.onPause();
        if (m_camera != null) {
            m_camera.release();
            m_camera = null;
            m_preview = null;
            m_decode = null;
        }
    }
    private void ActivateCamera() {
        if (m_camera != null) {
            m_camera = null;
        }
        try {
            m_camera = Camera.open();
        } catch (Exception e) {
            m_status.setText("The camera could not be accessed");
        }
        if (m_decode != null) {
            m_decode = null;
        }
        m_decode = new Decode(this);
        if (m_preview != null) {
            m_preview = null;
        }
        try {
            Camera.Parameters params;
            params = m_camera.getParameters();

            params.setFocusMode(Camera.Parameters.FOCUS_MODE_MACRO);
            params.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
            m_camera.setParameters(params);

        } catch (Exception e) {
        }
        m_preview = new CameraPreview(this, m_camera);
        m_preview.AddDecoder(m_decode);
        m_cameraFrame.addView(m_preview);
    }
}
